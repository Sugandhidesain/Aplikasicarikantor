export const colors = {
  white: '#FFFFFF',
  primary: '#E65605',
  secondary: '#FFE9DD',
  black: '#0E0E0E',
  grey: '#878787',
  greyContainer: '#E9E9E9',
  greyLight: '#F8F8F8',
  transparentBlack: 'rgba(0, 0, 0, 0.35)',
};
